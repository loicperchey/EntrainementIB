//
public class Tata 
{
    public static void main(String[]args)
    {
        System.out.println("Comment ça va Tata ?");
    }
}
